package demo.spring.selenium.stepdefinitions;

import demo.spring.selenium.pages.DashboardPage;
import demo.spring.selenium.pages.HomePage;
import io.cucumber.java.en.And;

public class DashboardPageSteps {
    private DashboardPage dashboardPage = new DashboardPage(Hooks.driver);

    @And("I should see {string} text")
    public void iShouldSeeText(String displayText) {
        dashboardPage.cekLogin(displayText);
    }
}
